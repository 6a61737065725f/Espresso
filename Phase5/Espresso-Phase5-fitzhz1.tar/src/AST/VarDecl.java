package AST;

public interface VarDecl {

    public Type type() ;
    public String name() ;

    public boolean isClassType() ;
    public int address();

}

    
