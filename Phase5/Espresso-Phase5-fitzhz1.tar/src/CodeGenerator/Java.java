package CodeGenerator;

import Utilities.*;
import AST.*;

public class Java extends Visitor {

    // intentionally left blank - will be filled in for phase 6
}
